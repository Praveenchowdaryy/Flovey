
import React from 'react';
import { Truck, Sparkles, ShieldCheck, Clock } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: "Handpicked Daily",
      description: "Morning-harvested blooms that stay vibrant for longer.",
      color: "bg-brand-pink/40",
      textColor: "text-rose-600"
    },
    {
      icon: <Truck className="w-8 h-8" />,
      title: "Gentle Delivery",
      description: "Carefully handled and delivered in climate-controlled bags.",
      color: "bg-brand-mint/50",
      textColor: "text-emerald-700"
    },
    {
      icon: <ShieldCheck className="w-8 h-8" />,
      title: "Quality Vow",
      description: "If it's not perfect, we make it right. No questions asked.",
      color: "bg-brand-lavender/50",
      textColor: "text-purple-600"
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "Always Ready",
      description: "Order by 2PM for same-day pastel perfection.",
      color: "bg-brand-peach/60",
      textColor: "text-orange-600"
    }
  ];

  return (
    <div className="py-24 bg-white/50">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className={`p-10 rounded-[2.5rem] transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 border border-white/50 ${feature.color}`}
            >
              <div className={`mb-6 bg-white/80 w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm ${feature.textColor}`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-serif font-bold text-slate-800 mb-3">{feature.title}</h3>
              <p className="text-sm text-slate-600/80 leading-relaxed font-medium">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;
