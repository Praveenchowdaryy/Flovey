
import React from 'react';
import { MessageCircle, Instagram, Mail, Sparkle, Clock, MapPin } from 'lucide-react';
import { WHATSAPP_NUMBER, INSTAGRAM_HANDLE, DOMAIN } from '../constants';

const Contact: React.FC = () => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=Hi Flovey! I have a question about my Bengaluru order.`;
  const instagramUrl = `https://instagram.com/${INSTAGRAM_HANDLE}`;

  return (
    <div className="py-24 bg-brand-pastel">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="bg-white rounded-[3rem] shadow-xl overflow-hidden grid lg:grid-cols-2 border border-brand-pink/20">
          {/* Digital Ordering Info */}
          <div className="p-10 md:p-16 border-b lg:border-b-0 lg:border-r border-gray-100">
            <span className="text-brand-rose font-bold text-xs uppercase tracking-[0.3em] mb-4 block">Let's Connect</span>
            <h2 className="text-4xl md:text-5xl font-serif text-slate-800 mb-6">Floral Consultations</h2>
            <p className="text-slate-500 mb-12 max-w-lg italic text-lg font-light leading-relaxed">
              Based in the heart of the garden city. Seeking something bespoke for your Bengaluru home? We're here to bloom with you.
            </p>

            <div className="space-y-10">
              <div className="flex items-center gap-8 group cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-brand-mint text-emerald-600 flex items-center justify-center transition-all group-hover:scale-110 shadow-sm shrink-0">
                  <MessageCircle size={32} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">WhatsApp Chat</p>
                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="text-2xl font-serif text-slate-800 hover:text-emerald-600 transition-colors">
                    Message Us Now
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-8 group cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-brand-pink text-brand-rose flex items-center justify-center transition-all group-hover:scale-110 shadow-sm shrink-0">
                  <Instagram size={32} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Instagram</p>
                  <a href={instagramUrl} target="_blank" rel="noopener noreferrer" className="text-2xl font-serif text-slate-800 hover:text-brand-rose transition-colors">
                    @{INSTAGRAM_HANDLE}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-8 group cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-brand-lavender text-purple-600 flex items-center justify-center transition-all group-hover:scale-110 shadow-sm shrink-0">
                  <Mail size={32} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Email</p>
                  <p className="text-2xl font-serif text-slate-800">hello@{DOMAIN}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Operational Details */}
          <div className="bg-brand-pink/30 p-10 md:p-16 flex flex-col justify-center relative">
            <div className="absolute -top-10 -right-10 opacity-10 pointer-events-none rotate-12">
                <Sparkle size={400} />
            </div>
            
            <div className="relative z-10 space-y-12">
              <div>
                <h3 className="text-2xl font-serif font-bold text-brand-rose mb-6 flex items-center gap-2">
                  <MapPin className="text-brand-rose" />
                  Service Area
                </h3>
                <p className="text-xl text-slate-700 font-light leading-relaxed">
                  We currently deliver exclusively within <span className="font-bold text-slate-800">Bengaluru City limits</span>. From Indiranagar to Whitefield, we bring freshness to your doorstep.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-serif font-bold text-brand-rose mb-6 flex items-center gap-2">
                  <Clock className="text-brand-rose" />
                  Delivery Hours
                </h3>
                <p className="text-xl text-slate-700 font-light leading-relaxed">
                  Monday — Sunday<br />
                  <span className="font-bold text-slate-800">10:00 AM — 08:00 PM</span><br />
                  <span className="text-sm italic text-slate-500">Orders placed after 2PM are scheduled for next-day delivery.</span>
                </p>
              </div>

              <div className="pt-8">
                <div className="p-6 bg-white/60 backdrop-blur-sm rounded-3xl border border-white/50 text-center shadow-sm">
                   <p className="text-sm font-medium text-brand-rose tracking-widest uppercase">Direct-to-Home Service</p>
                   <p className="text-xs text-slate-400 mt-2">No physical storefront — Curated Studio Orders Only</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
