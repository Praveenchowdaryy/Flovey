
import React, { useState, useEffect } from 'react';
import { Menu, X, ShoppingBag, Instagram } from 'lucide-react';
import { BUSINESS_NAME, INSTAGRAM_HANDLE } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      // Background change on scroll
      setIsScrolled(window.scrollY > 50);

      // Active section detection
      const sections = ['home', 'shop', 'about', 'contact'];
      const scrollPosition = window.scrollY + 100; // Offset for header

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home', id: 'home' },
    { name: 'Shop', href: '#shop', id: 'shop' },
    { name: 'About', href: '#about', id: 'about' },
    { name: 'Contact', href: '#contact', id: 'contact' },
  ];

  const instagramUrl = `https://instagram.com/${INSTAGRAM_HANDLE}`;

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between">
        {/* Logo - Also acts as Home link */}
        <a 
          href="#home" 
          onClick={() => {
            setIsOpen(false);
            setActiveSection('home');
          }}
          className="text-2xl md:text-3xl font-serif font-bold text-brand-rose flex items-center gap-2 group"
          aria-label="Flovey Home"
        >
          <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-brand-rose text-white flex items-center justify-center group-hover:rotate-12 transition-transform">
            <ShoppingBag size={20} />
          </div>
          <span className="tracking-tight">{BUSINESS_NAME}</span>
        </a>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className={`text-sm font-medium transition-all hover:scale-105 uppercase tracking-widest ${
                activeSection === link.id ? 'text-brand-rose' : 'text-gray-700 hover:text-brand-rose'
              }`}
            >
              {link.name}
            </a>
          ))}
          <div className="h-6 w-px bg-gray-200"></div>
          <a 
            href={instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-pink-600 transition-colors"
            title="Follow us on Instagram"
          >
            <Instagram size={22} />
          </a>
          <a 
            href="#contact" 
            className="bg-brand-rose text-white px-6 py-2 rounded-full hover:bg-rose-700 transition-all shadow-md hover:shadow-lg font-medium text-sm"
          >
            Order Now
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-colors" 
          onClick={() => setIsOpen(!isOpen)}
          aria-label={isOpen ? "Close Menu" : "Open Menu"}
        >
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="md:hidden bg-white/98 backdrop-blur-lg absolute top-full left-0 w-full shadow-2xl border-t border-gray-100 flex flex-col items-center py-10 space-y-6 animate-in slide-in-from-top duration-300">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className={`text-2xl font-serif font-medium transition-colors ${
                activeSection === link.id ? 'text-brand-rose' : 'text-gray-800'
              }`}
              onClick={() => {
                setIsOpen(false);
                setActiveSection(link.id);
              }}
            >
              {link.name}
            </a>
          ))}
          <div className="flex gap-6 py-4">
             <a 
                href={instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 rounded-full bg-pink-50 text-pink-600 flex items-center justify-center"
                onClick={() => setIsOpen(false)}
             >
                <Instagram size={24} />
             </a>
          </div>
          <a 
            href="#contact" 
            className="bg-brand-rose text-white px-10 py-4 rounded-full font-bold shadow-xl active:scale-95 transition-transform"
            onClick={() => setIsOpen(false)}
          >
            Send WhatsApp Order
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
