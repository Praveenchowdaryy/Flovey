
import React from 'react';
import { ShoppingBag, Instagram, Facebook, Twitter, MessageCircle, MapPin } from 'lucide-react';
import { BUSINESS_NAME, DOMAIN, WHATSAPP_NUMBER, INSTAGRAM_HANDLE } from '../constants';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white pt-20 pb-10 border-t border-brand-pink/10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="col-span-1 lg:col-span-1">
            <a href="#home" className="text-3xl font-serif font-bold text-brand-rose flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-brand-rose text-white flex items-center justify-center">
                <ShoppingBag size={20} />
              </div>
              <span>{BUSINESS_NAME}</span>
            </a>
            <p className="text-gray-500 mb-8 leading-relaxed">
              Premium online flower artisans delivering fresh bouquets, roses, and curated gifts exclusively across <span className="text-brand-rose font-medium">Bengaluru city</span>.
            </p>
            <div className="flex space-x-4">
              <a 
                href={`https://instagram.com/${INSTAGRAM_HANDLE}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-2 rounded-full border border-gray-100 text-gray-400 hover:text-brand-rose hover:border-brand-rose transition-all"
              >
                <Instagram size={20} />
              </a>
              <a href="#" className="p-2 rounded-full border border-gray-100 text-gray-400 hover:text-brand-rose hover:border-brand-rose transition-all">
                <Facebook size={20} />
              </a>
              <a href="#" className="p-2 rounded-full border border-gray-100 text-gray-400 hover:text-brand-rose hover:border-brand-rose transition-all">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-gray-900 font-bold mb-6 uppercase tracking-widest text-sm">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#home" className="text-gray-500 hover:text-brand-rose transition-colors">Home</a></li>
              <li><a href="#shop" className="text-gray-500 hover:text-brand-rose transition-colors">Floral Shop</a></li>
              <li><a href="#about" className="text-gray-500 hover:text-brand-rose transition-colors">About Flovey</a></li>
              <li><a href="#contact" className="text-gray-500 hover:text-brand-rose transition-colors">Contact Us</a></li>
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4 className="text-gray-900 font-bold mb-6 uppercase tracking-widest text-sm">Bengaluru Service</h4>
            <ul className="space-y-4 text-gray-500 text-sm">
              <li className="flex items-center gap-2"><MapPin size={14} className="text-brand-pink" /> Indiranagar</li>
              <li className="flex items-center gap-2"><MapPin size={14} className="text-brand-pink" /> Koramangala</li>
              <li className="flex items-center gap-2"><MapPin size={14} className="text-brand-pink" /> Whitefield</li>
              <li className="flex items-center gap-2"><MapPin size={14} className="text-brand-pink" /> HSR Layout & More</li>
            </ul>
          </div>

          {/* Order Support */}
          <div>
            <h4 className="text-gray-900 font-bold mb-6 uppercase tracking-widest text-sm">Order Support</h4>
            <p className="text-gray-500 mb-6 text-sm">
              Available daily for Bengaluru order tracking and custom requests via WhatsApp.
            </p>
            <a 
              href={`https://wa.me/${WHATSAPP_NUMBER}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-emerald-50 text-emerald-600 px-4 py-3 rounded-xl border border-emerald-100 hover:bg-emerald-100 transition-colors font-semibold"
            >
              <MessageCircle size={20} />
              WhatsApp Helpdesk
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            © {currentYear} {BUSINESS_NAME} - Bengaluru's Floral Artisans.
          </p>
          <div className="flex gap-8">
            <a href="#" className="text-xs text-gray-400 hover:text-brand-rose uppercase tracking-widest">Privacy Policy</a>
            <a href="#" className="text-xs text-gray-400 hover:text-brand-rose uppercase tracking-widest">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
