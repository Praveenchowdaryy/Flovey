
import React, { useState } from 'react';
import { MessageCircle, ExternalLink, ImageOff } from 'lucide-react';
import { Product, WHATSAPP_NUMBER, DOMAIN } from '../constants';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [imgError, setImgError] = useState(false);

  const whatsappMsg = encodeURIComponent(
    `Hello Flovey! I am interested in ordering the "${product.name}" bouquet (ID: ${product.id}). Is it available for delivery in Bengaluru?`
  );
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappMsg}`;

  const jsonLd = {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": product.name,
    "image": product.image,
    "description": product.description,
    "sku": product.id,
    "brand": {
      "@type": "Brand",
      "name": "Flovey"
    },
    "offers": {
      "@type": "Offer",
      "url": `https://${DOMAIN}/#shop`,
      "priceCurrency": "INR",
      "price": product.price,
      "itemCondition": "https://schema.org/NewCondition",
      "availability": "https://schema.org/InStock",
      "seller": {
        "@type": "Organization",
        "name": "Flovey"
      }
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-[0_25px_50px_-12px_rgba(251,113,133,0.15)] hover:-translate-y-2 transition-all duration-700 ease-out group border border-brand-pink/20 hover:border-brand-rose/30">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      
      <div className="relative aspect-[4/5] overflow-hidden bg-brand-pastel flex items-center justify-center">
        {!imgError ? (
          <img 
            src={product.image} 
            alt={product.altText} 
            loading="lazy"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-110"
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-brand-rose/30">
            <ImageOff size={48} strokeWidth={1} />
            <span className="text-[10px] uppercase tracking-widest font-bold">Image Unavailable</span>
          </div>
        )}
        
        <div className="absolute top-5 left-5 z-20">
          <span className="bg-white/95 backdrop-blur-sm text-brand-rose text-[10px] font-bold px-3 py-1.5 rounded-full uppercase tracking-widest shadow-sm border border-brand-pink/30">
            {product.id}
          </span>
        </div>

        <div className="absolute inset-0 bg-brand-rose/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center gap-4 z-10 backdrop-blur-[1px]">
          <a 
            href={whatsappUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-brand-mint text-emerald-700 p-5 rounded-full hover:scale-110 active:scale-95 transition-transform shadow-xl border-4 border-white/80"
            title="Buy via WhatsApp"
          >
            <MessageCircle size={28} />
          </a>
        </div>
      </div>
      
      <div className="p-8 bg-white relative">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-serif font-bold text-slate-800 group-hover:text-brand-rose transition-colors duration-300">
            {product.name}
          </h3>
          <span className="text-xl font-bold text-brand-rose shrink-0 ml-4">₹{product.price}</span>
        </div>
        
        {/* Short Description - Clearly visible */}
        <p className="text-sm text-slate-500 font-light line-clamp-2 mb-8 h-10 leading-relaxed italic">
          {product.description}
        </p>
        
        <div className="flex gap-3">
          <a 
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-2 bg-brand-mint hover:bg-emerald-50 text-emerald-700 py-4 rounded-2xl font-bold text-xs md:text-sm transition-all shadow-sm hover:shadow-md active:scale-95 border border-emerald-100 uppercase tracking-widest"
          >
            <MessageCircle size={18} />
            Quick Order
          </a>
          <button 
            className="p-4 rounded-2xl border border-brand-pink/30 text-brand-rose hover:bg-brand-pink/50 transition-all active:scale-95"
            aria-label="Product Inquiries"
          >
            <ExternalLink size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
