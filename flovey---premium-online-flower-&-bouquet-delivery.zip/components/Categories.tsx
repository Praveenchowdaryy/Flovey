
import React from 'react';

interface CategoriesProps {
  categories: string[];
  selected: string;
  onSelect: (category: string) => void;
}

const Categories: React.FC<CategoriesProps> = ({ categories, selected, onSelect }) => {
  return (
    <div className="flex flex-wrap justify-center gap-4 mb-12">
      {categories.map((cat) => (
        <button
          key={cat}
          onClick={() => onSelect(cat)}
          className={`px-6 py-2 rounded-full border transition-all duration-300 font-medium ${
            selected === cat 
            ? 'bg-brand-rose border-brand-rose text-white shadow-md' 
            : 'bg-white border-gray-200 text-gray-600 hover:border-brand-rose hover:text-brand-rose'
          }`}
        >
          {cat}
        </button>
      ))}
    </div>
  );
};

export default Categories;
