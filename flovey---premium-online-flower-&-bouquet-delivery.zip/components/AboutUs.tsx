
import React from 'react';
import { Heart, Leaf } from 'lucide-react';

const AboutUs: React.FC = () => {
  return (
    <div className="py-32 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8 grid md:grid-cols-2 gap-20 items-center">
        <div className="relative">
          {/* Pastel Accents */}
          <div className="absolute -top-16 -left-16 w-64 h-64 bg-brand-pink/20 rounded-full blur-[80px]"></div>
          <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-brand-lavender/30 rounded-full blur-[80px]"></div>
          
          <div className="relative z-10 overflow-hidden rounded-[4rem] border-[12px] border-brand-pastel shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1591880911020-d3446664a7a7?q=80&w=1000&auto=format&fit=crop" 
              alt="Artisanal pastel flower delivery service Bengaluru - Flovey" 
              className="w-full object-cover aspect-[4/5] hover:scale-105 transition-transform duration-1000"
            />
          </div>
          
          <div className="absolute -bottom-10 left-10 bg-brand-mint/90 backdrop-blur-md p-10 rounded-[2.5rem] shadow-xl z-20 border border-white/50 animate-bounce-slow">
            <p className="text-5xl font-serif text-emerald-700 font-bold mb-1">Local</p>
            <p className="text-xs text-emerald-800 font-bold uppercase tracking-[0.2em]">Exclusively Bengaluru</p>
          </div>
        </div>

        <div>
          <span className="text-brand-rose font-bold text-xs uppercase tracking-[0.3em] mb-6 block">Our Floral Journey</span>
          <h2 className="text-4xl md:text-6xl font-serif text-slate-800 mb-8 leading-[1.1]">
            Curating <span className="text-brand-rose italic">Elegance</span> for Bengaluru homes.
          </h2>
          <div className="space-y-6 text-slate-500 leading-relaxed mb-12 font-light text-lg">
            <p>
              Welcome to <strong>Flovey</strong>, your premier choice for <strong>online flower delivery in Bengaluru</strong>. We believe flowers are the world's most eloquent language, capable of whispering what words cannot.
            </p>
            <p>
              Our <strong>pastel-first approach</strong> ensures every bouquet delivered across the city is a masterpiece of subtlety and charm. We source directly from artisanal farms near Bengaluru, selecting only the softest textures to represent your feelings.
            </p>
            <p>
              Whether it’s a milestone birthday or an intimate anniversary, our <strong>WhatsApp-first shop</strong> makes sending a piece of nature’s beauty across Bengaluru effortless and deeply personal.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8">
            <div className="flex items-center gap-4 group">
              <div className="p-4 bg-brand-pink/40 rounded-2xl text-brand-rose group-hover:bg-brand-rose group-hover:text-white transition-all duration-500">
                <Leaf size={24} />
              </div>
              <p className="font-serif font-bold text-slate-800 text-lg">Eco-Wrapped</p>
            </div>
            <div className="flex items-center gap-4 group">
              <div className="p-4 bg-brand-lavender/40 rounded-2xl text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-all duration-500">
                <Heart size={24} />
              </div>
              <p className="font-serif font-bold text-slate-800 text-lg">Soulfully Tied</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
